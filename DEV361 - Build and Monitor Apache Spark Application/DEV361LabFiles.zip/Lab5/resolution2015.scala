/*_________________________________________________________________________*/
/*************************Lab 5.1 **************************

// 1.	Loads sfpd.csv
//	2. Creates a DataFrame (inferred schema by reflection)
//	3. Registers the DataFrame as a table
//  4. Prints the top three categories to the console
//	5. Finds the address, resolution, date and time for burglaries in 2015
//	6. Saves this to a JSON file in a folder /<user home>/appoutput  */
package solutions
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import sqlContext._
import sqlContext.implicits._

object resolution2015 {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Resolution2015")
    val sc = new SparkContext(conf)
    
    //1. loads sfpd.csv
    val sfpdRDD = sc.textFile("/user/user01/data/sfpd.csv").map(inc=>inc.split(","))
    
    //2. Create DataFrame - inferred schema by reflection
    case class Incidents(incidentnum:String, category:String, description:String, dayofweek:String, date:String, time:String, pddistrict:String, resolution:String, address:String, X:Float, Y:Float, pdid:String)

    val sfpdCase=sfpdRDD.map(inc=>Incidents(inc(0),inc(1), inc(2),inc(3),inc(4),inc(5),inc(6),inc(7),inc(8),inc(9).toFloat,inc(10).toFloat, inc(11)))

    val sfpdDF=sfpdCase.toDF()

    //3. Registering as table 
    sfpdDF.registerTempTable("sfpd")

    // 4. Top 3 categories
    val top3Cat = sfpdDF.groupBy("category").count.sort($"count".desc).show(3)
    val top3CatSQL=sqlContext.sql("SELECT category, count(incidentnum) AS inccount FROM sfpd GROUP BY category ORDER BY inccount DESC LIMIT 3")
    top3CatSQL.collect.foreach(println)

    //5. Find address, resolutions, date and time for burglaries in 2015
    def getyear(s:String):String = {
    val year = s.substring(s.lastIndexOf('/')+1)
    year
    }
    sqlContext.udf.register("getyear",getyear _)

    val res2015 = sqlContext.sql("SELECT address,resolution, date, time FROM sfpd WHERE getyear(date)='15'")
    inc2014.collect.foreach(println)

    res2015.toJSON.saveAsTextFile("/user/user01/appoutput")
    }
}



